// reset db placeholder
console.log('reset db script');
